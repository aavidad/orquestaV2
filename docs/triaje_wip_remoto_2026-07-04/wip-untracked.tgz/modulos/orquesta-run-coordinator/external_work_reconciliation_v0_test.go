package orquestaruncoordinator

import "testing"

func TestReconcileExternalWorkPublicStatusV0NoDeclaraDoneSiJobDominioSiguePendingSinTareas(t *testing.T) {
	got := ReconcileExternalWorkPublicStatusV0(ExternalWorkReconciliationInputV0{
		RunRef:              "run-ref-opes-pending-001",
		ProjectionStatus:    "done",
		ProjectionTaskCount: 0,
		DomainJobStatus:     "pending",
		EvidenceRefs:        []string{"projection-ref-001", "domain-job-ref-001"},
	})

	if got.PublicStatus != ExternalWorkPublicStatusBlockedV0 ||
		got.Action != ExternalWorkReconcileActionReopenOrBlockDomainV0 ||
		got.Reason != "projection_done_but_domain_job_pending_without_open_tasks" ||
		!got.Justified ||
		!got.Reconciled ||
		!containsRunCoordinatorStringForTestV0(got.CausalSourceRefs, "run_projection") ||
		!containsRunCoordinatorStringForTestV0(got.CausalSourceRefs, "domain_job_state") {
		t.Fatalf("decision=%+v", got)
	}
	if got.PublicStatus == ExternalWorkPublicStatusCompletedV0 ||
		got.PublicStatus == ExternalWorkPublicStatusRunningV0 {
		t.Fatalf("estado publico falso: %+v", got)
	}
}

func TestReconcileExternalWorkPublicStatusV0AckCompletedEnDiscoGanaAEstadoRunningStale(t *testing.T) {
	got := ReconcileExternalWorkPublicStatusV0(ExternalWorkReconciliationInputV0{
		RunRef:                 "run-ref-ack-completed-001",
		ProjectionStatus:       "running",
		ProjectionTaskCount:    1,
		DomainJobStatus:        "pending",
		AgentAckCompleted:      true,
		AgentCheckpointPresent: true,
		ProcessRegistryChecked: true,
		ProcessAlive:           false,
		Liveness: RunLivenessClassificationV0{
			Class: RunLivenessClassRunningStaleNoProcessV0,
			Stale: true,
		},
		EvidenceRefs: []string{"ack-ref-001"},
	})

	if got.PublicStatus != ExternalWorkPublicStatusCompletedV0 ||
		got.Action != ExternalWorkReconcileActionIngestAckV0 ||
		got.Reason != "completed_ack_observed" ||
		!got.Justified ||
		!got.Reconciled ||
		!containsRunCoordinatorStringForTestV0(got.CausalSourceRefs, "agent_ack_checkpoint") ||
		!containsRunCoordinatorStringForTestV0(got.CausalSourceRefs, "process_registry") {
		t.Fatalf("decision=%+v", got)
	}
	if got.PublicStatus == ExternalWorkPublicStatusRunningV0 ||
		got.Action == ExternalWorkReconcileActionObserveV0 {
		t.Fatalf("ACK completado no fue ingerido como fuente causal: %+v", got)
	}
}

func containsRunCoordinatorStringForTestV0(values []string, want string) bool {
	for _, value := range values {
		if value == want {
			return true
		}
	}
	return false
}
